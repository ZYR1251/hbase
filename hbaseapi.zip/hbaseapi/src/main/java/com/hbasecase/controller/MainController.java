package com.hbasecase.controller;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import org.apache.hadoop.hbase.TableName;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.hbasecase.entity.HbaseTable;
import com.hbasecase.util.HBaseUtil;
import com.alibaba.fastjson.JSONObject;
@Controller
public class MainController {
	//插入界面
	@GetMapping("hbaseinsert")
	public String hbaseform(Model model) {
		HbaseTable hb = new HbaseTable();
		//addAttribute将数据返回前端代码中
		model.addAttribute("hb", hb);
		return "user/hbaseinsert";
	}
	//提交之后执行插入功能
	@RequestMapping("hbase")
	public String hbase(@ModelAttribute HbaseTable hbaseTable) {
		HBaseUtil hBaseUtil = new HBaseUtil();
		String tableName = hbaseTable.getTableName();
		String family = hbaseTable.getFamily();
		String[] columnFamily = new String[1];
		columnFamily[0]=family;
		hBaseUtil.creatTable(tableName, columnFamily);
		hBaseUtil.insert(hbaseTable.getTableName(), hbaseTable.getRowKey(), hbaseTable.getFamily(), hbaseTable.getQualifier(), hbaseTable.getValue());
		return "redirect:/hbaselist";
	}
	
	@RequestMapping("hbaselist")
	public String findhbase(Model model) throws IOException {
		HBaseUtil hBaseUtil = new HBaseUtil();
		HbaseTable ht = new HbaseTable();
		List<HbaseTable> list1 = new ArrayList<HbaseTable>();
		for(TableName t_name:hBaseUtil.getListTable()) {
  		  List<Map<String, Object>> select = hBaseUtil.select(t_name.getNameAsString());
  		  for(Map<String,Object> i:select) {
  			ht = JSONObject.parseObject(JSONObject.toJSONString(i), HbaseTable.class);
  			ht.setTableName(t_name.getNameAsString());
  			  list1.add(ht);
  		  }
  	  }
		model.addAttribute("list1",list1);
		return "user/hbaselist";	
	}
	
}
